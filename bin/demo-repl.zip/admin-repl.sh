#!/usr/bin/env bash
rm -rf ~/.ammonite/cache

echo "restUrl=${restUrl}"

java -Drest.url=${restUrl} -jar xap-admin-repl-*.jar "$@"